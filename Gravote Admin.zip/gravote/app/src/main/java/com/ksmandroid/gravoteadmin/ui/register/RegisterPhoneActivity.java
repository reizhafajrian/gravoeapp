package com.ksmandroid.gravoteadmin.ui.register;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.model.OTPResponse;
import com.ksmandroid.gravoteadmin.network.OTPNetworkConfig;
import com.ksmandroid.gravoteadmin.network.OTPService;
import com.ksmandroid.gravoteadmin.ui.verifyotp.VerifyOTPActivity;
import com.ksmandroid.gravoteadmin.utils.CustomTextWatcher;
import com.ksmandroid.gravoteadmin.views.LoadingDialog;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterPhoneActivity extends AppCompatActivity implements View.OnClickListener {

    private TextInputEditText etPhone, etPassword, etConfirmPassword;
    private MaterialButton btnNextToOtp;
    boolean isClickPassword = true, isClickConfPassword = true;
    private String phone, password, confirmPass, textPhone = "", textPassword = "",
            textConfirmPass = "";
    private OTPService api;
    private LoadingDialog loading = new LoadingDialog(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_phone);

        initiateAPI();
        initiateUI();

    }

    private void initiateAPI() {
        api = new OTPNetworkConfig(this).api();
    }

    private void initiateUI() {
        etPhone = findViewById(R.id.et_phone_regis_phone);
        etPassword = findViewById(R.id.et_password_regis_phone);
        etConfirmPassword = findViewById(R.id.et_confirm_pass_regis_phone);
        btnNextToOtp = findViewById(R.id.btn_next_to_otp);
        ImageButton btnBack = findViewById(R.id.btn_back_regis_phone);
        ImageButton togglePassword = findViewById(R.id.btn_toggle_pass_regis_phone);
        ImageButton toggleConfirmPass = findViewById(R.id.btn_toggle_confirm_pass_regis_phone);

        btnNextToOtp.setEnabled(false);
        btnBack.setOnClickListener(this);
        btnNextToOtp.setOnClickListener(this);
        togglePassword.setOnClickListener(this);
        toggleConfirmPass.setOnClickListener(this);

        etPhone.addTextChangedListener(phoneTextWatcher);
        etPassword.addTextChangedListener(phoneTextWatcher);
        etConfirmPassword.addTextChangedListener(phoneTextWatcher);
    }

    private TextWatcher phoneTextWatcher = new CustomTextWatcher() {

        @Override
        public void afterTextChanged(Editable s) {
            textPhone = etPhone.getText().toString().trim();
            textPassword = etPassword.getText().toString().trim();
            textConfirmPass = etConfirmPassword.getText().toString().trim();
            if(!TextUtils.isEmpty(textPhone) || !TextUtils.isEmpty(textPassword) ||
               textConfirmPass.matches(textPassword)) {
                btnNextToOtp.setEnabled(true);
            } else {
                btnNextToOtp.setEnabled(false);
            }
        }

    };

    //function ini harap dibuat di dalam sebuah static di dalam class
    //fungsinya sebagai cek valid password untuk class lainnya juga
    private boolean isValidPassword(String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN =
                "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=*])(?=\\S+$).{8,24}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }

    private boolean isValidMobile(String phone) {
        Pattern pattern;
        Matcher matcher;
        final String PHONE_PATTERN = "^(?=.*[0-9])(?=\\S+$).{8,15}$";
        pattern = Pattern.compile(PHONE_PATTERN);
        matcher = pattern.matcher(phone);
        return matcher.matches();
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btn_back_regis_phone:
                onBackPressed();
                break;
            case R.id.btn_next_to_otp:
                textPhone = etPhone.getText().toString().trim();
                textPassword = etPassword.getText().toString().trim();
                textConfirmPass = etConfirmPassword.getText().toString().trim();
                if(!isValidPassword(textPassword)) {
                    Toast.makeText(RegisterPhoneActivity.this,
                                   "Gunakan minimal 8 karakter dengan campuran huruf besar, huruf kecil, angka dan simbol!",
                                   Toast.LENGTH_SHORT).show();
                } else if(!isValidMobile(textPhone)) {
                    Toast.makeText(RegisterPhoneActivity.this,
                                   getString(R.string.failed_phone_numbers_invalid),
                                   Toast.LENGTH_SHORT).show();
                } else {
                    String phoneWithCode = changeToIndoCodeNumber(textPhone);
                    sendRequestOtp(phoneWithCode);
                }
                break;
            case R.id.btn_toggle_pass_regis_phone:
                if(isClickPassword) {
                    hidePassword(etPassword);
                    isClickPassword = false;
                } else {
                    showPassword(etPassword);
                    isClickPassword = true;
                }
                break;
            case R.id.btn_toggle_confirm_pass_regis_phone:
                if(isClickConfPassword) {
                    hidePassword(etConfirmPassword);
                    isClickConfPassword = false;
                } else {
                    showPassword(etConfirmPassword);
                    isClickConfPassword = true;
                }
                break;
        }
    }

    private void showPassword(TextInputEditText et) {
        et.setTransformationMethod(PasswordTransformationMethod.getInstance());
        et.setSelection(et.getText().length());
    }

    private void hidePassword(TextInputEditText et) {
        et.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        et.setSelection(et.getText().length());
    }

    private void sendRequestOtp(String numbers) {
        loading.showDialog();
        api.requestOtp(numbers, getString(R.string.request_channel_otp)).enqueue(
                new Callback<OTPResponse>() {
                    @Override
                    public void onResponse(Call<OTPResponse> call, Response<OTPResponse> response) {
                        loading.hideDialog();
                        if(response.body().getStatus().matches("pending")) {
                            Intent intent = new Intent(RegisterPhoneActivity.this,
                                                       VerifyOTPActivity.class);
                            intent.putExtra("phoneNumbers", textPhone);
                            startActivity(intent);
                            Toast.makeText(RegisterPhoneActivity.this,
                                           getString(R.string.success_request_otp),
                                           Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(RegisterPhoneActivity.this, getString(
                                    R.string.failed_request_otp_invalid_phone_numbers),
                                           Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<OTPResponse> call, Throwable t) {
                        loading.hideDialog();
                        Toast.makeText(RegisterPhoneActivity.this,
                                       getString(R.string.failed_connection), Toast.LENGTH_LONG)
                                .show();
                    }
                });
    }

    public String changeToIndoCodeNumber(String phoneNumbers) {
        int index = phoneNumbers.length();
        return "+62" + phoneNumbers.substring(1, index);
    }

}