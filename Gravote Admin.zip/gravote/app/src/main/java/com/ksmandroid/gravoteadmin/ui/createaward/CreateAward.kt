package com.ksmandroid.gravoteadmin.ui.createaward

import android.annotation.SuppressLint
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import com.github.appintro.AppIntro
import com.github.appintro.AppIntroCustomLayoutFragment
import com.github.appintro.AppIntroPageTransformerType
import com.ksmandroid.gravoteadmin.R
@Suppress("DEPRECATION")
class CreateAward : AppIntro() {
    @RequiresApi(Build.VERSION_CODES.M)

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setColorDoneText(R.color.colorPrimary)
        supportActionBar?.hide()
        setImageNextButton(resources.getDrawable(R.drawable.ic_group_111))
        setImagebackButton(resources.getDrawable(R.drawable.ic_group_111))
        setIndicatorColor(
            selectedIndicatorColor = getColor(R.color.colorPrimaryDark),
            unselectedIndicatorColor = getColor(R.color.unselectedots))
        slide()
        isSkipButtonEnabled=false
        showStatusBar(true)
        onPageSelected(0)
        setText()
        setTransformer(
            AppIntroPageTransformerType.Parallax(
            titleParallaxFactor = 1.0,
            imageParallaxFactor = -1.0,
            descriptionParallaxFactor = 5.0
        ))
    }

    override fun onPageSelected(position: Int) {
        super.onPageSelected(position)
        isWizardMode =position==1||position==2
    }

    override fun onSkipPressed(currentFragment: Fragment?) {
        super.onSkipPressed(currentFragment)

        finish()
    }
    override fun onDonePressed(currentFragment: Fragment?) {
        super.onDonePressed(currentFragment)
        // Decide what to do when the user clicks on "Done"
        finish()
    }

    private fun setImagebackButton(imageNextButton: Drawable) {
        val backButton = findViewById<ImageView>(R.id.back)
        backButton.setImageDrawable(imageNextButton)

    }
    @SuppressLint("SetTextI18n")
    fun setText(): TextView? {
        val doneText = findViewById<TextView>(R.id.done)
        doneText.text = "Lanjutkan"
        doneText.setTextColor(resources.getColor(R.color.colorPrimaryDark))
        return doneText
    }

    fun slide(){
        addSlide(
            AppIntroCustomLayoutFragment.newInstance(
                R.layout.fragment_create_award
            ))
        addSlide(AppIntroCustomLayoutFragment.newInstance(

        ))
        addSlide(AppIntroCustomLayoutFragment.newInstance(
        ))
    }

}