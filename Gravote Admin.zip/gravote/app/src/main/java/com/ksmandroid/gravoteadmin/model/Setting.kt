package com.ksmandroid.gravoteadmin.model

data class Setting(
    val name: String,
    val icon: Int
)
