package com.ksmandroid.gravoteadmin.adapter

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ksmandroid.gravoteadmin.R
import kotlinx.android.synthetic.main.item_header_photo.view.*

class ListPhotoAdapter(private val listPhoto: MutableList<Uri?>) :
    RecyclerView.Adapter<ListPhotoAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_header_photo, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = listPhoto.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listPhoto[position] ?: Uri.EMPTY)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(photo: Uri?) {
            with(itemView) {
                container_photo.setImageURI(photo)
            }
        }

    }

}