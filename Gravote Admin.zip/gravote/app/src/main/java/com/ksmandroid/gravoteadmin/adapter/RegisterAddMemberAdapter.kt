package com.ksmandroid.gravoteadmin.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.listener.AddMemberListener
import com.ksmandroid.gravoteadmin.model.AddMember
import kotlinx.android.synthetic.main.item_regis_add_member.view.*
import org.jetbrains.anko.textColor

class RegisterAddMemberAdapter(private val listener: AddMemberListener) :
    RecyclerView.Adapter<RegisterAddMemberAdapter.ViewHolder>() {

    private val list = mutableListOf<AddMember>()

    fun setList(list: MutableList<AddMember>) {
        this.list.addAll(list)
        notifyDataSetChanged()
    }

    fun clear() {
        list.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_regis_add_member, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position], listener)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(data: AddMember, listener: AddMemberListener) {
            with(itemView) {
                civ_photo_item_regis_add_member.setImageResource(data.photo)
                tv_name_item_regis_add_member.text = data.name
                tv_username_item_regis_add_member.text = data.username
                btn_add_item_regis_add_member.isChecked = data.isAdded
                //Mengubah warna text dalam ToggleButton
                if (data.isAdded) {
                    btn_add_item_regis_add_member.textColor =
                        ContextCompat.getColor(itemView.context, R.color.colorWhite)
                } else {
                    btn_add_item_regis_add_member.textColor =
                        ContextCompat.getColor(itemView.context, R.color.colorPrimary)
                }
                btn_add_item_regis_add_member.setOnClickListener {
                    listener.onBtnMemberClick(
                        AddMember(
                            data.photo,
                            data.name,
                            data.username,
                            data.isAdded
                        )
                    )
                }
            }
        }

    }

}