package com.ksmandroid.gravoteadmin.ui.register

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.ui.home.HomeActivity
import kotlinx.android.synthetic.main.activity_register_success.*
import org.jetbrains.anko.intentFor

class RegisterSuccess : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_success)

        btn_welcome_regis_success.setOnClickListener {
            val intent = intentFor<HomeActivity>()
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

    }
}
