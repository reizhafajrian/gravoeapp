package com.ksmandroid.gravoteadmin.listener

interface SpinnerItemListener {

    fun onItemSpinnerListener(text: String, resId: Int)

}