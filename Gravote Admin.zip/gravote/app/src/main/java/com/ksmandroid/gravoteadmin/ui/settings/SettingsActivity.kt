package com.ksmandroid.gravoteadmin.ui.settings

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.adapter.SettingsAdapter
import com.ksmandroid.gravoteadmin.listener.BottomSheetItemListener
import com.ksmandroid.gravoteadmin.listener.SettingsItemClickListener
import com.ksmandroid.gravoteadmin.model.Setting
import com.ksmandroid.gravoteadmin.sharedpreferences.SharedPrefManager
import com.ksmandroid.gravoteadmin.ui.editpassword.EditPasswordActivity
import com.ksmandroid.gravoteadmin.ui.editprofile.EditProfileActivity
import com.ksmandroid.gravoteadmin.ui.login.LoginActivity
import com.ksmandroid.gravoteadmin.views.BottomSheetAlertFragment
import kotlinx.android.synthetic.main.activity_settings.*
import kotlinx.android.synthetic.main.toolbar.*
import org.jetbrains.anko.intentFor

class SettingsActivity : AppCompatActivity(),
    SettingsItemClickListener,
    BottomSheetItemListener,
    View.OnClickListener {

    private val list: MutableList<Setting> = mutableListOf()
    private val alert by lazy { BottomSheetAlertFragment(this) }
    private val pref by lazy { SharedPrefManager(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        list.addAll(SettingsObject.listData)
        initiateUI()

    }

    private fun initiateUI() {
        btn_back_toolbar.setOnClickListener(this)
        tv_toolbar.text = "Pengaturan"
        rv_settings.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        rv_settings.setHasFixedSize(true)
        getVersion()
        showRecyclerList()
    }

    private fun showRecyclerList() {
        rv_settings.layoutManager = LinearLayoutManager(this)
        val listSettingsAdapter =
            SettingsAdapter(list, this)
        rv_settings.adapter = listSettingsAdapter
    }

    private fun getVersion() {
        val version = getString(R.string.version)
        tv_version.text = "Version $version"
    }

    override fun onItemClick(nameSetting: String) {
        when (nameSetting) {
            //ini dibuat enum class, variabelnya yang dibutuhin text yang ada di layout dan icon
            //dalam bentuk int
            "Edit Profile" -> {
                startActivity(intentFor<EditProfileActivity>())
            }
            "Ganti Password" -> {
                startActivity(intentFor<EditPasswordActivity>())
            }
            "Kontak Kami" -> {
                goToIgKSMAndroid()
            }
            "Keluar" -> {
                showBottomSheetAlert()
            }
        }
    }

    private fun showBottomSheetAlert() {
        alert.setTitle(getString(R.string.exit))
        alert.setSubTitle(getString(R.string.sub_title_alert_logout))
        alert.setTextYesBtn(getString(R.string.exit))
        alert.setTextNoBtn(getString(R.string.text_no_btn_alert))
        alert.show(supportFragmentManager, getString(R.string.tag_bottom_sheet_alert))
    }

    private fun goToIgKSMAndroid() {
        //ini tidak perlu dimasukkan ke strings.xml
        val uri = Uri.parse("https://www.instagram.com/_u/androidupnvj/")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.setPackage("com.instagram.android")
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/androidupnvj/")
                )
            )
        }
    }

    override fun getUserChoice(yes: Boolean) {
        if (yes) {
            pref.clearStateLogin()
            startActivity(intentFor<LoginActivity>())
            finish()
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_back_toolbar -> {
                onBackPressed()
            }
        }
    }
}





