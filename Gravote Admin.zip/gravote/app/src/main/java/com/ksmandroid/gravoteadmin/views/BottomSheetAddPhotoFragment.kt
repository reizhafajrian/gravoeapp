package com.ksmandroid.gravoteadmin.views

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.listener.AddPhotoListener
import com.ksmandroid.gravoteadmin.model.AddPhotoType
import kotlinx.android.synthetic.main.bts_add_photo.*

class BottomSheetAddPhotoFragment(private val listener: AddPhotoListener) :
    BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.bts_add_photo, container)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btn_camera_bts_add_photo.setOnClickListener {
            listener.onIconClick(AddPhotoType.CAMERA)
        }
        btn_gallery_bts_add_photo.setOnClickListener {
            listener.onIconClick(AddPhotoType.GALLERY)
        }
    }
}