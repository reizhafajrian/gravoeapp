package com.ksmandroid.gravoteadmin.ui.register

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ksmandroid.gravoteadmin.R
import kotlinx.android.synthetic.main.activity_register_profile_welcome.*
import org.jetbrains.anko.intentFor

class RegisterProfileWelcomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_profile_welcome)

        btn_regis_profile_welcome.setOnClickListener {
            startActivity(intentFor<RegisterProfileActivity>())
        }
    }

}
