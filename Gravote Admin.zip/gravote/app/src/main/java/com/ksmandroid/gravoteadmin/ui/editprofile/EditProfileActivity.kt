package com.ksmandroid.gravoteadmin.ui.editprofile

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.adapter.ListPhotoAdapter
import com.ksmandroid.gravoteadmin.listener.AddPhotoListener
import com.ksmandroid.gravoteadmin.listener.BottomSheetItemListener
import com.ksmandroid.gravoteadmin.listener.SpinnerItemListener
import com.ksmandroid.gravoteadmin.model.AddPhotoType
import com.ksmandroid.gravoteadmin.utils.ExtraKey.Companion.FROM_CAMERA_CODE
import com.ksmandroid.gravoteadmin.utils.ExtraKey.Companion.FROM_GALLERY_CODE
import com.ksmandroid.gravoteadmin.utils.ExtraKey.Companion.PERMISSION_CODE
import com.ksmandroid.gravoteadmin.views.BottomSheetAddPhotoFragment
import com.ksmandroid.gravoteadmin.views.BottomSheetAlertFragment
import com.ksmandroid.gravoteadmin.views.BottomSheetSpinnerFragment
import kotlinx.android.synthetic.main.activity_edit_profile.*
import kotlinx.android.synthetic.main.toolbar.*
import org.jetbrains.anko.longToast

class EditProfileActivity : AppCompatActivity(),
    View.OnClickListener,
    SpinnerItemListener,
    AddPhotoListener,
    BottomSheetItemListener {

    //untuk mendapatkan uri image menggunakan camera
    private var imageCameraUri: Uri? = Uri.EMPTY

    //untuk mengetahui id dari view yang sedang digunakan untuk camera atau galeri
    private var resIdPhoto: Int? = 0

    //state yang digunakan untuk permission supaya mengambil image dari mana
    private var isFromCamera: Boolean? = true
    private var textNameOrganization = ""
    private var textTypeOrganization = ""
    private var textUniversity = ""
    private var textFaculty = ""

    //sebagai variabel untuk image uri dari camera atau galeri dan digunakan sebagai state button save
    private var imageUri: Uri? = Uri.EMPTY

    //sebagai variabel untuk list image yang digunakan untuk header
    private val listPhoto = mutableListOf<Uri?>()

    //Jika ada list data dummy, value string tidak perlu dimasukkan strings.xml
    //Karena nanti sudah pasti data ini tidak terpakai jika backend sudah ada
    private val listTypeOrganization =
        listOf("Kelompok Studi Mahasiswa", "Badan Eksekutif Mahasiswa")
    private val listUniversity = listOf("UPN Veteran Jakarta")
    private val listFaculty = listOf(
        "Fakultas Ekonomi dan Bisnis",
        "Fakultas Teknik",
        "Fakultas Ilmu Komputer",
        "Fakultas Hukum",
        "Fakultas Ilmu Sosial dan Ilmu Politik",
        "Fakultas Kedokteran",
        "Fakultas Ilmu Kesehatan"
    )

    private val btsAddPhoto by lazy { BottomSheetAddPhotoFragment(this) }
    private val btsSpinner by lazy { BottomSheetSpinnerFragment(this, this) }
    private val btsAlert by lazy { BottomSheetAlertFragment(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        initiateUI()

    }

    private fun initiateUI() {
        btn_back_toolbar.setOnClickListener(this)
        tv_toolbar.text = getString(R.string.edit_profile)
        //Nanti sebelum iniatiate UI hit api terlebih dahulu untuk mendapatkan data dari backend
        et_name_organization_edit_profile.setText(getString(R.string.organization_name))
        et_type_organization_edit_profile.setText(getString(R.string.organization_type))
        et_university_edit_profile.setText(getString(R.string.university_name))
        et_faculty_edit_profile.setText(getString(R.string.faculty_name))
        btn_add_photo_edit_profile.setOnClickListener(this)
        tv_add_photo_edit_profile.setOnClickListener(this)
        et_type_organization_edit_profile.setOnClickListener(this)
        et_university_edit_profile.setOnClickListener(this)
        et_faculty_edit_profile.setOnClickListener(this)
        btn_add_photo_header_edit_profile.setOnClickListener(this)
        btn_save_edit_profile.setOnClickListener(this)
        showListPhoto()
    }

    private fun showListPhoto() {
        rv_photo_organization_edit_profile.setHasFixedSize(true)
        rv_photo_organization_edit_profile.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        val listPhotoAdapter = ListPhotoAdapter(listPhoto)
        rv_photo_organization_edit_profile.adapter = listPhotoAdapter
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_back_toolbar -> {
                onBackPressed()
            }

            R.id.btn_save_edit_profile -> {
                textNameOrganization = et_name_organization_edit_profile.text.toString().trim()
                textTypeOrganization = et_type_organization_edit_profile.text.toString().trim()
                textUniversity = et_university_edit_profile.text.toString().trim()
                textFaculty = et_faculty_edit_profile.text.toString().trim()
                if (imageUri != Uri.EMPTY && textNameOrganization.isNotEmpty() &&
                    textTypeOrganization.isNotEmpty() && textUniversity.isNotEmpty() &&
                    textFaculty.isNotEmpty() && listPhoto.isNotEmpty()
                ) {
                    btsAlert.setTitle(getString(R.string.edit_profile))
                    btsAlert.setSubTitle(getString(R.string.sub_title_alert_edit_profile))
                    btsAlert.setTextYesBtn(getString(R.string.text_yes_btn_alert))
                    btsAlert.setTextNoBtn(getString(R.string.text_no_btn_alert))
                    btsAlert.show(
                        supportFragmentManager,
                        getString(R.string.tag_bottom_sheet_alert)
                    )
                } else {
                    longToast(getString(R.string.failed_btn_save_field_empty))
                }
            }

            R.id.btn_add_photo_edit_profile, R.id.tv_add_photo_regis_profile -> {
                showAddPhotoBottomSheet(R.id.btn_add_photo_regis_profile)
            }

            R.id.btn_add_photo_header_edit_profile -> {
                showAddPhotoBottomSheet(R.id.btn_add_photo_header_regis_profile)
            }

            R.id.et_type_organization_edit_profile -> {
                showSpinnerBottomSheet(
                    getString(R.string.title_spinner_bottom_sheet_type_organization),
                    R.id.et_type_organization_edit_profile,
                    listTypeOrganization
                )
            }

            R.id.et_university_edit_profile -> {
                showSpinnerBottomSheet(
                    getString(R.string.title_spinner_bottom_sheet_university_name),
                    R.id.et_university_edit_profile,
                    listUniversity
                )
            }

            R.id.et_faculty_edit_profile -> {
                showSpinnerBottomSheet(
                    getString(R.string.title_spinner_bottom_sheet_faculty_name),
                    R.id.et_faculty_regis_profile,
                    listFaculty
                )
            }
        }
    }

    private fun showAddPhotoBottomSheet(resId: Int) {
        resIdPhoto = resId
        btsAddPhoto.show(supportFragmentManager, getString(R.string.tag_bottom_sheet_add_photo))
    }

    private fun showSpinnerBottomSheet(title: String, resId: Int, list: List<String>) {
        btsSpinner.setTitle(title)
        btsSpinner.setResId(resId)
        btsSpinner.setList(list)
        btsSpinner.show(supportFragmentManager, getString(R.string.tag_bottom_sheet_spinner))
    }

    private fun pickImageFromCamera() {
        //if system os is Marshmallow or Above, we need to request runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED ||
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED
            ) {
                //permission was not enabled
                val permission =
                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                isFromCamera = true
                //show popup to request permission
                requestPermissions(permission, PERMISSION_CODE)
            } else {
                //permission already granted
                openCamera()
            }
        } else {
            //system os is < marshmallow
            openCamera()
        }
    }

    private fun pickImageFromGallery() {
        //if system os is Marshmallow or Above, we need to request runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED ||
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED
            ) {
                //permission was not enabled
                val permission =
                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                isFromCamera = false
                //show popup to request permission
                requestPermissions(permission, PERMISSION_CODE)
            } else {
                //permission already granted
                openGalery()
            }
        } else {
            //system os is < marshmallow
            openGalery()
        }
    }

    private fun openGalery() {
        //Intent to pick image
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, FROM_GALLERY_CODE)
    }

    private fun openCamera() {
        val values = ContentValues()
        values.put(MediaStore.Images.Media.TITLE, "New Picture")
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera")
        imageCameraUri =
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        //camera intent
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageCameraUri)
        startActivityForResult(intent, FROM_CAMERA_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        //called when user presses ALLOW or DENY from Permission Request Popup
        when (requestCode) {
            PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    //permission from popup was granted
                    when (isFromCamera) {
                        true -> pickImageFromCamera()
                        false -> pickImageFromGallery()
                    }
                } else {
                    //permission from popup was denied
                    Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && resIdPhoto == R.id.btn_add_photo_regis_profile) {
            when (requestCode) {
                FROM_CAMERA_CODE -> {
                    btn_add_photo_edit_profile.setImageURI(imageCameraUri)
                    imageUri = imageCameraUri
                }

                FROM_GALLERY_CODE -> {
                    btn_add_photo_edit_profile.setImageURI(data?.data)
                    imageUri = data?.data

                }
            }
        } else if (resultCode == Activity.RESULT_OK && resIdPhoto == R.id.btn_add_photo_header_regis_profile) {
            when (requestCode) {
                FROM_CAMERA_CODE -> {
                    listPhoto.add(imageCameraUri)
                }

                FROM_GALLERY_CODE -> {
                    listPhoto.add(data?.data)
                }
            }
            showListPhoto()
        } else {
            longToast(getString(R.string.failed_add_photo))
        }
        btsAddPhoto.dismiss()
    }

    override fun onItemSpinnerListener(text: String, resId: Int) {
        when (resId) {
            R.id.et_type_organization_edit_profile -> {
                et_type_organization_edit_profile.setText(text)
                textTypeOrganization = text
            }

            R.id.et_university_edit_profile -> {
                et_university_edit_profile.setText(text)
                textUniversity = text
            }

            R.id.et_faculty_edit_profile -> {
                et_faculty_edit_profile.setText(text)
                textFaculty = text
            }
        }
        btsSpinner.dismiss()
    }

    override fun onIconClick(addPhotoType: AddPhotoType) {
        when (addPhotoType) {
            //Nanti ini dibuat enum class aja
            AddPhotoType.CAMERA -> {
                pickImageFromCamera()
            }
            AddPhotoType.GALLERY -> {
                pickImageFromGallery()
            }
        }
    }

    override fun getUserChoice(yes: Boolean) {
        if (yes) {
            // hit api untuk kirim ke backend
            longToast(getString(R.string.success_edit_profile))
        }
    }

}
