package com.ksmandroid.gravoteadmin.utils

class ExtraKey {

    companion object {
        const val PERMISSION_CODE = 200
        const val FROM_CAMERA_CODE = 201
        const val FROM_GALLERY_CODE = 202
    }

}