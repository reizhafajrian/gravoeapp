package com.ksmandroid.gravoteadmin.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textview.MaterialTextView;
import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.model.Notification;
import com.ksmandroid.gravoteadmin.ui.notification.NotificationActivity;

import java.util.ArrayList;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private ArrayList<Notification> notifList;

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public NotificationAdapter(ArrayList<Notification> list) {
        this.notifList = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_show_notif_home,
                                                                     parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(position);
    }

    @Override
    public int getItemCount() {
        return notifList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private MaterialTextView tvDescriptionNotif, tvTimeNotif;
        private ImageView ivNotifRead;

        private ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDescriptionNotif = itemView.findViewById(R.id.tv_description_notif_home);
            tvTimeNotif = itemView.findViewById(R.id.tv_time_notif_home);
            ivNotifRead = itemView.findViewById(R.id.iv_notif_cek_home);
        }

        void bind(int position) {
            Notification list = notifList.get(position);
            tvDescriptionNotif.setText(list.getDescriptionNotif());
            tvTimeNotif.setText(list.getTimeNotif());
            boolean notifCek = Boolean.parseBoolean(list.getNotifRead());
            ivNotifRead.setEnabled(notifCek);
            itemView.setOnClickListener(v -> {
                onItemClickCallback.onItemClicked(notifList.get(getAdapterPosition()));
                NotificationActivity.listStateNotif[position] = "true";
            });
        }

    }

    public interface OnItemClickCallback {

        void onItemClicked(Notification data);

    }

}