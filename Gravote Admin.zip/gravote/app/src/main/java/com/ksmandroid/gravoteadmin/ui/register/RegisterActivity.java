package com.ksmandroid.gravoteadmin.ui.register;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;
import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.utils.CustomTextWatcher;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private TextInputEditText etOrganizationName, etUsername, etEmail;
    private ImageButton toggleUsername;
    private MaterialButton btnNext;
    private MaterialTextView tvUsernameHelper, tvUsername;
    private String defaultUsername = "ksmandro";
    private boolean isValid = true;
    private final String EMAIL_PATTERN = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    private String textOrganisasi = "";
    private String textUsername = "";
    private String textEmail = "";
    private Context context = this;
    //waktu setelah user mengetik, setelah ada backend gunakan 1 detik saja (1000)
    //karena ada tambahan waktu untuk menunggu response dari backend
    private long delay = 3000;
    Handler handler = new Handler();

    //Timer untuk menunggu user selesai mengetik
    private Runnable timer = () -> {
        //nanti hit api di sini
        if(System.currentTimeMillis() > delay) {
            if(textUsername.equals(defaultUsername)) {
                usernameWarnCase(false, getString(R.string.helper_edit_text_username_exist));
            } else {
                usernameWarnCase(true, getString(R.string.helper_edit_text_username_accept));
            }
            checkEditText();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        initiateUI();

    }

    private void initiateUI() {
        ImageButton btnBack = findViewById(R.id.btn_back_register);
        etOrganizationName = findViewById(R.id.et_nama_organisasi_register);
        etUsername = findViewById(R.id.et_username_register);
        tvUsernameHelper = findViewById(R.id.tv_username_helper_register);
        tvUsername = findViewById(R.id.tv_username_register);
        etEmail = findViewById(R.id.et_email_register);
        btnNext = findViewById(R.id.btn_next_to_register_phone);
        toggleUsername = findViewById(R.id.btn_toggle_username_register);

        btnBack.setOnClickListener(this);
        btnNext.setOnClickListener(this);

        etOrganizationName.addTextChangedListener(registerTextWatcher);
        etUsername.addTextChangedListener(usernameTextWatcher);
        etEmail.addTextChangedListener(registerTextWatcher);
    }

    private TextWatcher registerTextWatcher = new CustomTextWatcher() {

        @Override
        public void afterTextChanged(Editable s) {
            textOrganisasi = etOrganizationName.getText().toString().trim();
            textEmail = etEmail.getText().toString().trim();
            checkEditText();
        }

    };

    private final TextWatcher usernameTextWatcher = new CustomTextWatcher() {

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            //untuk menghapus handler jika user masih sedang mengetik
            handler.removeCallbacks(timer);
        }

        @Override
        public void afterTextChanged(Editable editable) {
            textUsername = etUsername.getText().toString().toLowerCase().trim();

            if(TextUtils.isEmpty(textUsername)) {
                usernameWarnCase(true, getString(R.string.helper_edit_text_username_default));
                isValid = false;
            } else if(textUsername.length() < 8 || textUsername.length() >= 30) {
                usernameWarnCase(false, getString(R.string.helper_edit_text_username_minimal));
            } else if(textUsername.trim().contains(" ")) {
                usernameWarnCase(false,
                                 getString(R.string.helper_edit_text_username_without_space));
            } else {
                usernameWarnCase(true, getString(R.string.helper_edit_text_username_check));
                isValid = false;
                //initiate handler menunggu user selesai mengetik
                handler.postDelayed(timer, delay);
            }

            checkEditText();
        }
    };

    private void checkEditText() {
        if(textOrganisasi.length() < 7 || textUsername.length() < 8 || !textEmail.matches(
                EMAIL_PATTERN) || !isValid) {
            btnNext.setEnabled(false);
        } else {
            btnNext.setEnabled(true);
        }
    }

    public void usernameWarnCase(boolean isCondition, String textUsername) {
        tvUsernameHelper.setText(textUsername);
        if(isCondition) {
            tvUsernameHelper.setTextColor(ContextCompat.getColor(context, R.color.colorBlackLight));
            tvUsername.setTextColor(ContextCompat.getColor(context, R.color.colorGrayDarker));
            etUsername.setBackgroundResource(R.drawable.et_custom_register);
            toggleUsername.setVisibility(View.GONE);
            isValid = true;
        } else {
            tvUsernameHelper.setTextColor(ContextCompat.getColor(context, R.color.colorError));
            tvUsername.setTextColor(ContextCompat.getColor(context, R.color.colorError));
            etUsername.setBackgroundResource(R.drawable.et_red_warn);
            toggleUsername.setVisibility(View.VISIBLE);
            isValid = false;
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btn_back_register:
                onBackPressed();
                break;
            case R.id.btn_next_to_register_phone:
                textOrganisasi = etOrganizationName.getText().toString().trim();
                textUsername = etUsername.getText().toString().trim().toLowerCase();
                textEmail = etEmail.getText().toString().trim().toLowerCase();
                Intent intent = new Intent(RegisterActivity.this, RegisterPhoneActivity.class);
                startActivity(intent);
                break;
        }
    }

}