package com.ksmandroid.gravoteadmin.listener

interface BottomSheetItemListener {

    fun getUserChoice(yes: Boolean)

}