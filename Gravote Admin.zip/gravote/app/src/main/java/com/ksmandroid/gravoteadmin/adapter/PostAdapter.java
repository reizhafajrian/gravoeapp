package com.ksmandroid.gravoteadmin.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textview.MaterialTextView;
import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.model.PostModel;
import com.skyhope.showmoretextview.ShowMoreTextView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {

    private ArrayList<PostModel> listPost;
    private Context ctx;

    public PostAdapter(ArrayList<PostModel> list, Context ctx) {
        this.listPost = list;
        this.ctx = ctx;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_post, parent,
                                                                     false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PostModel list = listPost.get(position);
        holder.bind(list);
    }

    @Override
    public int getItemCount() {
        return listPost.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivPhoto, ivStat;
        private MaterialTextView tvTitle, tvStat, tvCategory, tvTime;
        private ShowMoreTextView tvDescription;

        private ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPhoto = itemView.findViewById(R.id.iv_avatar_post_item);
            tvTitle = itemView.findViewById(R.id.tv_title_post_item);
            tvStat = itemView.findViewById(R.id.tv_lock_stat_post_item);
            ivStat = itemView.findViewById(R.id.iv_lock_stat_post_item);
            tvCategory = itemView.findViewById(R.id.tv_category_post_item);
            tvDescription = itemView.findViewById(R.id.tv_desc_post_item);
            tvTime = itemView.findViewById(R.id.tv_time_post_item);
        }

        void bind(PostModel list) {
            tvTime.setText(list.getTimePost());
            tvDescription.setText(list.getDescriptionPost());
            tvDescription.setShowingLine(2);
            tvDescription.addShowMoreText("Baca Selengkapnya");
            tvDescription.addShowLessText("Baca Lebih Sedikit");
            tvDescription.setShowMoreColor(ContextCompat.getColor(ctx, R.color.colorPrimary));
            tvDescription.setShowLessTextColor(ContextCompat.getColor(ctx, R.color.colorPrimary));
            tvTitle.setText(list.getTitlePost());
            if(list.isMemberOnly()) {
                tvStat.setText(ctx.getText(R.string.lock_stat_home));
                ivStat.setImageResource(R.drawable.ic_lock_state_post);
            }
            //Seandainya post untuk umum atau bukan hanya untuk anggota
            //else {
            //    tvTitle.setText(ctx.getText(R.string.lock_stat_home));
            //    ivStat.setImageResource(R.drawable.ic_lock_state_post);
            //}
            tvCategory.setText(list.getCategoryPost());
            Picasso.with(itemView.getContext()).load(list.getPhotoPost()).into(ivPhoto);
        }

    }

}
