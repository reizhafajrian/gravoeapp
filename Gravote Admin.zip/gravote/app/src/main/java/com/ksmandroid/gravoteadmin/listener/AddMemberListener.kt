package com.ksmandroid.gravoteadmin.listener

import com.ksmandroid.gravoteadmin.model.AddMember

interface AddMemberListener {

    fun onBtnMemberClick(data: AddMember)

}