package com.ksmandroid.gravoteadmin.ui.profile;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textview.MaterialTextView;
import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.adapter.PostAdapter;
import com.ksmandroid.gravoteadmin.model.PostModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView rvPosts;
    private CircleImageView civMember3, civMember2, civMember;
    private MaterialTextView tvCountMember, tvSeeAllMember;
    private ArrayList<PostModel> listPost = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        listPost.addAll(getListPost());
        initiateUI();

    }

    private void initiateUI() {
        civMember = findViewById(R.id.civ_member);
        civMember2 = findViewById(R.id.civ_member_2);
        civMember3 = findViewById(R.id.civ_member_3);
        tvCountMember = findViewById(R.id.tv_count_member);
        ImageButton btnBack = findViewById(R.id.btn_back_regis_profile);
        ImageButton btnSetting = findViewById(R.id.btn_setting_profile);
        FloatingActionButton fabCreatePost = findViewById(R.id.fab_create_post);
        ImageButton btnSeeAllMembers = findViewById(R.id.btn_see_all_member_profile);
        tvSeeAllMember = findViewById(R.id.tv_see_all_member_profile);
        rvPosts = findViewById(R.id.rv_recent_posts);

        fabCreatePost.setOnClickListener(this);
        btnBack.setOnClickListener(this);
        btnSetting.setOnClickListener(this);
        btnSeeAllMembers.setOnClickListener(this);
        tvSeeAllMember.setOnClickListener(this);

        showCivMember();
        showPostList();
    }

    private void showCivMember() {
        int lengthMember = listPost.size();
        String memberPhoto = "", memberPhoto2 = "", memberPhoto3 = "";
        if(lengthMember > 0) {
            memberPhoto = listPost.get(0).getPhotoPost();
        }
        if(lengthMember > 1) {
            memberPhoto2 = listPost.get(1).getPhotoPost();
        }
        if(lengthMember > 2) {
            memberPhoto3 = listPost.get(2).getPhotoPost();
        }
        switch(lengthMember) {
            case 0:
                civMember3.setVisibility(View.INVISIBLE);
                civMember2.setVisibility(View.INVISIBLE);
                civMember.setVisibility(View.INVISIBLE);
                tvCountMember.setVisibility(View.INVISIBLE);
                tvSeeAllMember.setVisibility(View.INVISIBLE);
                break;
            case 1:
                civMember.setVisibility(View.VISIBLE);
                civMember2.setVisibility(View.INVISIBLE);
                civMember3.setVisibility(View.INVISIBLE);
                tvCountMember.setVisibility(View.VISIBLE);
                tvSeeAllMember.setVisibility(View.VISIBLE);
                Picasso.with(this).load(memberPhoto).into(civMember);
                break;
            case 2:
                civMember.setVisibility(View.VISIBLE);
                civMember2.setVisibility(View.VISIBLE);
                civMember3.setVisibility(View.INVISIBLE);
                tvCountMember.setVisibility(View.VISIBLE);
                tvSeeAllMember.setVisibility(View.VISIBLE);
                Picasso.with(this).load(memberPhoto).into(civMember);
                Picasso.with(this).load(memberPhoto2).into(civMember2);
                break;
            default:
                civMember.setVisibility(View.VISIBLE);
                civMember2.setVisibility(View.VISIBLE);
                civMember3.setVisibility(View.VISIBLE);
                tvCountMember.setVisibility(View.VISIBLE);
                tvSeeAllMember.setVisibility(View.VISIBLE);
                Picasso.with(this).load(memberPhoto).into(civMember);
                Picasso.with(this).load(memberPhoto2).into(civMember2);
                Picasso.with(this).load(memberPhoto3).into(civMember3);
                break;
        }
        tvCountMember.setText(String.valueOf(lengthMember));
    }

    public void seeAllMember() {
        //ini tidak perlu dimasukkan strings.xml
        Toast.makeText(this, "Button see all member clicked", Toast.LENGTH_SHORT).show();
    }

    //nanti ini dihapus ketika backend sudah ada
    private ArrayList<PostModel> getListPost() {
        String[] titlePost = getResources().getStringArray(R.array.array_title_post);
        String[] categoryPost = getResources().getStringArray(R.array.array_category_post);
        String[] descriptionPost = getResources().getStringArray(R.array.array_description_post);
        String[] photoPost = getResources().getStringArray(R.array.array_photo_post);
        String[] timePost = getResources().getStringArray(R.array.array_time_post);

        ArrayList<PostModel> list = new ArrayList<>();
        for(int i = 0; i < titlePost.length; i++) {
            PostModel post = new PostModel(titlePost[i], photoPost[i], categoryPost[i],
                                           descriptionPost[i], timePost[i], true);
            list.add(post);
        }
        return list;
    }

    private void showPostList() {
        rvPosts.addItemDecoration(
                new DividerItemDecoration(rvPosts.getContext(), DividerItemDecoration.VERTICAL));
        rvPosts.setHasFixedSize(true);
        rvPosts.setLayoutManager(new LinearLayoutManager(this));
        PostAdapter adapter = new PostAdapter(listPost, this);
        rvPosts.setAdapter(adapter);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.fab_create_post:
                Toast.makeText(ProfileActivity.this, "Dummy clicked button create post",
                               Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_back_regis_profile:
                onBackPressed();
                break;
            case R.id.btn_setting_profile:
                Toast.makeText(ProfileActivity.this, "Button Setting clicked", Toast.LENGTH_SHORT)
                        .show();
                break;
            case R.id.tv_see_all_member_profile:
            case R.id.btn_see_all_member_profile:
                seeAllMember();
                break;
        }
    }

}
