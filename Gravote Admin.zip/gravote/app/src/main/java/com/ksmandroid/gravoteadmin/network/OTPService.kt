package com.ksmandroid.gravoteadmin.network

import com.ksmandroid.gravoteadmin.model.OTPResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface OTPService {

    @FormUrlEncoded
    @POST("Verifications")
    fun requestOtp(
        @Field("To") phoneNumbers: String?, @Field("Channel") channel: String?
    ): Call<OTPResponse>

    @FormUrlEncoded
    @POST("VerificationCheck")
    fun verifyOTP(
        @Field("To") phoneNumbers: String?, @Field("Code") otpCode: String?
    ): Call<OTPResponse>

}