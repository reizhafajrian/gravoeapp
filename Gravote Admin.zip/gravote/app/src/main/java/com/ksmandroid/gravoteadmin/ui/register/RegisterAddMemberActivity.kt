package com.ksmandroid.gravoteadmin.ui.register

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.adapter.RegisterAddMemberAdapter
import com.ksmandroid.gravoteadmin.listener.AddMemberListener
import com.ksmandroid.gravoteadmin.model.AddMember
import kotlinx.android.synthetic.main.activity_register_add_member.*
import org.jetbrains.anko.intentFor

class RegisterAddMemberActivity : AppCompatActivity(), View.OnClickListener,
    AddMemberListener {

    private val adapter by lazy { RegisterAddMemberAdapter(this) }
    private val listEmpty = mutableListOf<AddMember>()
    private val listMember = mutableListOf<AddMember>()

    companion object {
        private val listMemberA = mutableListOf<AddMember>()
        private val listMemberB = mutableListOf<AddMember>()
        private val listMemberC = mutableListOf<AddMember>()
    }

    //ini hanya digunakan untuk memasukkan data lokal untuk uji coba untuk menampilkan data.
    //jika sudah ada data dari backend function ini dihapus saja
    private fun setAllList() {
        for (i in 1..10) {
            listMemberA.add(AddMember(R.drawable.logo_android, "Amalia$i", "amaliaja", false))
            listMemberB.add(AddMember(R.drawable.bg_logo, "Bagus$i", "bagusaja", false))
            listMemberC.add(AddMember(R.drawable.bg_logo_home, "Charlie$i", "charlieaja", false))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_add_member)

        setAllList()
        initiateUI()

    }

    private fun initiateUI() {
        btn_back_regis_add_member.setOnClickListener(this)
        sv_regis_add_member.setOnClickListener(this)
        sv_regis_add_member.setOnQueryTextListener(svListener)
        btn_save_regis_add_member.setOnClickListener(this)
        rv_regis_add_member.setHasFixedSize(true)
        rv_regis_add_member.layoutManager = LinearLayoutManager(this)
    }

    private fun showListMember(list: MutableList<AddMember>) {
        adapter.clear()
        adapter.setList(list)
        rv_regis_add_member.adapter = adapter
    }

    private val svListener = object : SearchView.OnQueryTextListener {
        override fun onQueryTextSubmit(query: String?): Boolean {
            //untuk saat search digunakan hanya mencari list berdasarkan huruf a,b,c
            //setelah backend kelar membuat api untuk search
            //nanti query ini di kirim ke backend untuk dicek nama/username
            //setelah itu akan dapat sebuah list yang bisa menampilkan data tersebut
            val text = query ?: ""
            when {
                text.contains("a") -> showListMember(listMemberA)
                text.contains("b") -> showListMember(listMemberB)
                text.contains("c") -> showListMember(listMemberC)
                else -> showListMember(listEmpty)
            }
            return true
        }

        override fun onQueryTextChange(query: String?): Boolean {
            val text = query ?: ""
            when {
                text.contains("a") -> showListMember(listMemberA)
                text.contains("b") -> showListMember(listMemberB)
                text.contains("c") -> showListMember(listMemberC)
                else -> showListMember(listEmpty)
            }
            return true
        }

    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_back_regis_add_member -> onBackPressed()
            R.id.btn_save_regis_add_member -> saveMember()
            R.id.sv_regis_add_member -> sv_regis_add_member.isIconified = false
        }
    }

    private fun saveMember() {
        startActivity(intentFor<RegisterSuccess>())
    }

    //listener ketika user sudah memencet tombol tambah atau hapus
    //isAdded ketika member sudah ditambahkan dan !isAdded ketika member belum ditambahkan
    override fun onBtnMemberClick(data: AddMember) {
        val list = when {
            listMemberA.contains(data) -> listMemberA
            listMemberB.contains(data) -> listMemberB
            else -> listMemberC
        }
        //variabel di bawah fungsinya untuk mengubah data secara lokal agar state button add member
        //berubah. jadi setelah backend jadi variabel ini diganti dengan list dari backend
        list[list.indexOf(data)].isAdded = !data.isAdded

        //fungsinya untuk menambahkan sebuah data ke dalam list lokal agar tombol enabled/bisa diklik
        if (data.isAdded) {
            listMember.remove(data)
        } else {
            listMember.add(data)
        }

        //variabel di bawah untuk memberitahu button save member jika data dalam list member sudah
        //ditambahkan maka tombol enabled/bisa diklik
        btn_save_regis_add_member.isEnabled = listMember.isNotEmpty()

        showListMember(list)
    }

}
