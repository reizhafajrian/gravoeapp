package com.ksmandroid.gravoteadmin.network

import android.content.Context
import com.ksmandroid.gravoteadmin.BuildConfig
import com.readystatesoftware.chuck.ChuckInterceptor
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

class OTPNetworkConfig(context: Context) {

    private val context by lazy { context }

    private fun getInterceptor(): OkHttpClient {
        val httpLoggingInterceptor = HttpLoggingInterceptor()
        httpLoggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
        val httpCacheDirectory = File(context.cacheDir, "responses")
        val cacheSize = 20 * 1024 * 1024 // 20 MiB
        val cache = Cache(httpCacheDirectory, cacheSize.toLong())

        val client = OkHttpClient.Builder()
        client.cache(cache)
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(AuthInterceptor(BuildConfig.OTP_USERNAME, BuildConfig.OTP_PASSWORD))
            .addInterceptor(ChuckInterceptor(context))

        return client.build()
    }

    private fun getNetwork(): Retrofit {
        return Retrofit.Builder().baseUrl(BuildConfig.OTP_BASE_URL)
            .client(getInterceptor())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    fun api(): OTPService {
        return getNetwork().create(OTPService::class.java)
    }

}