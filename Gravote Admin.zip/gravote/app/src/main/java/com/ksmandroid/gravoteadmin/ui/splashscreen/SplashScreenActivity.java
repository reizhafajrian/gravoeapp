package com.ksmandroid.gravoteadmin.ui.splashscreen;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.sharedpreferences.SharedPrefManager;
import com.ksmandroid.gravoteadmin.ui.home.HomeActivity;
import com.ksmandroid.gravoteadmin.ui.login.LoginActivity;

public class SplashScreenActivity extends AppCompatActivity {

    private SharedPrefManager pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);

        Animation topAnim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        Animation bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);

        ImageView ivLogo = findViewById(R.id.iv_logo_splash_screen);
        TextView tvDeveloper = findViewById(R.id.tv_developer_splash_screen);

        pref = new SharedPrefManager(this);

        ivLogo.setAnimation(topAnim);
        tvDeveloper.setAnimation(bottomAnim);

        int splashDelay = 3000;
        new Handler().postDelayed(() -> {
            Intent intent;
            if(pref.isAlreadyLogin()) {
                intent = new Intent(SplashScreenActivity.this, HomeActivity.class);
            } else {
                intent = new Intent(SplashScreenActivity.this, LoginActivity.class);
            }
            startActivity(intent);
            finish();
        }, splashDelay);
    }

}

