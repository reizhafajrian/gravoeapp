package com.ksmandroid.gravoteadmin.utils

fun String.changeToIndoCodeNumbers(): String {
    val phoneNumbers = this
    return "+62" + phoneNumbers.substring(1, phoneNumbers.lastIndex.plus(1))
}

fun String.splitPhoneNumbers(): String {
    val phoneNumbers = this
    val firstSplit = phoneNumbers.substring(0, 4)
    val secondSplit = phoneNumbers.substring(4, 8)
    val thirdSplit = phoneNumbers.substring(8, phoneNumbers.lastIndex.plus(1))
    return "$firstSplit-$secondSplit-$thirdSplit"
}