package com.ksmandroid.gravoteadmin.views

import android.app.Dialog
import android.content.Context
import com.ksmandroid.gravoteadmin.R

class LoadingDialog(context: Context) {

    private val dialog by lazy { Dialog(context) }

    fun showDialog() {
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.loading_dialog)
        dialog.show()
    }

    fun hideDialog() {
        dialog.dismiss()
    }

}