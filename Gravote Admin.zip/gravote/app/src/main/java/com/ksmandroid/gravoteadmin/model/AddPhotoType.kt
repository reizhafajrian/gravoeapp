package com.ksmandroid.gravoteadmin.model

import com.ksmandroid.gravoteadmin.R

enum class AddPhotoType(val icon: Int, val text: String) {
    CAMERA(R.drawable.ic_camera, "Kamera"),
    GALLERY(R.drawable.ic_gallery, "Galeri")
}