package com.ksmandroid.gravoteadmin.ui.notification;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.adapter.NotificationAdapter;
import com.ksmandroid.gravoteadmin.model.Notification;

import java.util.ArrayList;

public class NotificationActivity extends AppCompatActivity
        implements NotificationAdapter.OnItemClickCallback {

    private RecyclerView rvNotification;
    private ArrayList<Notification> list = new ArrayList<>();
    //setelah backend sudah ada, list ini dihapus
    public static String[] listStateNotif = {"false", "false", "false", "false"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_home);

        list.addAll(getListPost());
        showNotificationList();

    }

    //setelah backend ada function ini dihapus
    private ArrayList<Notification> getListPost() {
        String[] descriptionPost = getResources().getStringArray(R.array.description_notif);
        String[] timePost = getResources().getStringArray(R.array.array_time_post);

        ArrayList<Notification> listHero = new ArrayList<>();
        for(int i = 0; i < descriptionPost.length; i++) {
            Notification post = new Notification(descriptionPost[i], timePost[i],
                                                 listStateNotif[i]);
            listHero.add(post);
        }
        return listHero;
    }

    private void showNotificationList() {
        rvNotification = findViewById(R.id.rv_notif_home);

        rvNotification.addItemDecoration(new DividerItemDecoration(rvNotification.getContext(),
                                                                   DividerItemDecoration.VERTICAL));
        rvNotification.setHasFixedSize(true);
        rvNotification.setLayoutManager(new LinearLayoutManager(this));
        NotificationAdapter listNotifAdapter = new NotificationAdapter(list);
        rvNotification.setAdapter(listNotifAdapter);
        listNotifAdapter.setOnItemClickCallback(this);
    }

    @Override
    public void onItemClicked(Notification data) {
        showNotificationList();
        Toast.makeText(this, data.getDescriptionNotif(), Toast.LENGTH_SHORT).show();
    }

}