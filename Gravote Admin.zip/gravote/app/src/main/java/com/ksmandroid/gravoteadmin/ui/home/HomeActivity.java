package com.ksmandroid.gravoteadmin.ui.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.adapter.PostAdapter;
import com.ksmandroid.gravoteadmin.model.PostModel;
import com.ksmandroid.gravoteadmin.ui.notification.NotificationActivity;
import com.ksmandroid.gravoteadmin.ui.profile.ProfileActivity;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView rvNewPost;
    private ArrayList<PostModel> list = new ArrayList<>();
    private ImageView ivProfile, ivLogoOrganization, ivNotif, ivSeeAllVote, ivSeeAllPost, ivNotVote;
    private TextView tvNameOrganization, tvVoteCreated, tvSumMember, tvNewStatVote, tvTimeVote,
            tvTitleVote, tvChategoryVote, tvpartisipanNotVote;
    private CardView cvMakePost, cvHistoryVote, cvMakeVote, cvMember;
    private Context ctx = this;
    //24 jam = 86400000L,
    // untuk percobaan time from db
    private long timeCd = 86400000L;
    private LinearLayout containerTime, containerPartisipanVote;

    //untuk percobaan on Going, finished, created, pratisipannotvote gak ada atau msh ada.
    private String dbStatusNewVote = "ongoing", titleVote = "Pemilihan Presiden", categoryVote =
            "Award", partisipanNotVote = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        list.addAll(getListPost());
        initiateUI();

    }

    private void initiateUI() {
        rvNewPost = findViewById(R.id.rv_new_post_home);
        ivProfile = findViewById(R.id.iv_avatar_home);
        ivLogoOrganization = findViewById(R.id.iv_logo_organisasi_home);
        ivNotif = findViewById(R.id.iv_notif_home);
        ivNotVote = findViewById(R.id.iv_warning_not_vote);
        ivSeeAllVote = findViewById(R.id.iv_see_all_vote);
        ivSeeAllPost = findViewById(R.id.iv_see_all_post);
        tvNameOrganization = findViewById(R.id.tv_name_organisasi_home);
        tvVoteCreated = findViewById(R.id.tv_vote_made_home);
        tvSumMember = findViewById(R.id.tv_sum_member_home);
        tvNewStatVote = findViewById(R.id.tv_voting_status_open);
        tvTimeVote = findViewById(R.id.tv_time_new_vote_home);
        tvTitleVote = findViewById(R.id.tv_title_new_vote_home);
        tvChategoryVote = findViewById(R.id.tv_chategory_new_vote);
        tvpartisipanNotVote = findViewById(R.id.tv_partisipan_not_vote);
        containerTime = findViewById(R.id.ll_time_new_vote);
        containerPartisipanVote = findViewById(R.id.ll_partisipan_not_vote);

        cvMakeVote = findViewById(R.id.cv_make_voting_home);
        cvHistoryVote = findViewById(R.id.cv_history_vote_home);
        cvMakePost = findViewById(R.id.cv_make_posting_home);
        cvMember = findViewById(R.id.cv_member_home);

        ivNotif.setOnClickListener(this);
        ivProfile.setOnClickListener(this);
        ivSeeAllVote.setOnClickListener(this);
        ivSeeAllPost.setOnClickListener(this);
        cvMakePost.setOnClickListener(this);
        cvHistoryVote.setOnClickListener(this);
        cvMakeVote.setOnClickListener(this);
        cvMember.setOnClickListener(this);

        showPostList();

        checkStateVote();
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.iv_avatar_home:
                Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(intent);
                break;

            case R.id.iv_notif_home:
                Intent notification = new Intent(this, NotificationActivity.class);
                startActivity(notification);
                break;

            case R.id.cv_make_voting_home:
                //text tidak perlu dimasukkan ke dalam strings.xml
                //karena hanya sementara backend belom ada
                //begitupun yang lainnya
                Toast.makeText(getApplicationContext(), "Voting HOME BISA", Toast.LENGTH_LONG)
                        .show();
                break;

            case R.id.cv_history_vote_home:
                Toast.makeText(getApplicationContext(), "History HOME BISA", Toast.LENGTH_LONG)
                        .show();
                break;

            case R.id.cv_make_posting_home:
                Toast.makeText(getApplicationContext(), "Posting HOME BISA", Toast.LENGTH_LONG)
                        .show();
                break;

            case R.id.cv_member_home:
                Toast.makeText(getApplicationContext(), "Member HOME BISA", Toast.LENGTH_LONG)
                        .show();
                break;

            case R.id.iv_see_all_vote:
                Toast.makeText(getApplicationContext(), "All Vote HOME BISA", Toast.LENGTH_LONG)
                        .show();
                break;

            case R.id.iv_see_all_post:
                Toast.makeText(getApplicationContext(), "All Post HOME BISA", Toast.LENGTH_LONG)
                        .show();
                break;
        }
    }

    //Jika sudah ada backend funtion ini dihapus
    private ArrayList<PostModel> getListPost() {
        String[] titlePost = getResources().getStringArray(R.array.array_title_post);
        String[] categoryPost = getResources().getStringArray(R.array.array_category_post);
        String[] descriptionPost = getResources().getStringArray(R.array.array_description_post);
        String[] photoPost = getResources().getStringArray(R.array.array_photo_post);
        String[] timePost = getResources().getStringArray(R.array.array_time_post);

        ArrayList<PostModel> list = new ArrayList<>();
        for(int i = 0; i < titlePost.length; i++) {
            PostModel post = new PostModel(titlePost[i], photoPost[i], categoryPost[i],
                                           descriptionPost[i], timePost[i], true);
            list.add(post);
        }
        return list;
    }

    private void showPostList() {
        rvNewPost.addItemDecoration(
                new DividerItemDecoration(rvNewPost.getContext(), DividerItemDecoration.VERTICAL));
        rvNewPost.setHasFixedSize(true);
        rvNewPost.setLayoutManager(new LinearLayoutManager(this));
        PostAdapter listHeroAdapter = new PostAdapter(list, ctx);
        rvNewPost.setAdapter(listHeroAdapter);
    }

    private void checkStateVote() {
        //percobaan dummy ketika get dbStatusNewVote dari Data Base
        switch(dbStatusNewVote) {
            //Nanti ini dibuat enum class
            case "create":
                showVote("create", "Voting Dibuat");
                break;

            case "ongoing":
                showVote("ongoing", "Voting Dibuka");
                newVoteCdt();
                break;

            case "finish":
                showVote("finish", "Voting Ditutup");
                break;
        }
    }

    private void showVote(String status, String tvStatVote) {
        tvTitleVote.setText(titleVote);
        tvChategoryVote.setText(categoryVote);
        tvNewStatVote.setText(tvStatVote);
        if(status.equals("ongoing")) {
            containerPartisipanVote.setVisibility(View.VISIBLE);
            containerTime.setVisibility(View.VISIBLE);
        } else {
            containerTime.setVisibility(View.INVISIBLE);
            containerPartisipanVote.setVisibility(View.INVISIBLE);
        }
    }

    private void newVoteCdt() {
        //Time With DB
        //long timeCalendar = calendar.getTimeInMillis();
        //timeCd = timeCalendar - getTimeFromDb;

        new CountDownTimer(timeCd, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                //harap dibuat static function untuk convert tipe data long ke detik, menit, dan jam
                //agar bisa digunakan untuk class lain juga
                String hour = String.valueOf(((millisUntilFinished / 1000) / 3600));
                String minute = String.valueOf((millisUntilFinished % (1000 * 3600)) / 60000);
                String seconds = String.valueOf((millisUntilFinished / 1000) % 60);

                if(Long.parseLong(hour) < 10) hour = "0" + hour;
                if(Long.parseLong(minute) < 10) minute = "0" + minute;
                if(Long.parseLong(seconds) < 10) seconds = "0" + seconds;

                tvTimeVote.setText(hour + ":" + minute + ":" + seconds);

                if(Integer.parseInt(partisipanNotVote) < 1) {
                    ivNotVote.setVisibility(View.GONE);
                    tvpartisipanNotVote.setTextColor(
                            ContextCompat.getColor(ctx, R.color.colorGrayDarker));
                    tvpartisipanNotVote.setText("Seluruh Partisipan Sudah Voting");
                } else {
                    ivNotVote.setVisibility(View.VISIBLE);
                    tvpartisipanNotVote.setTextColor(
                            ContextCompat.getColor(ctx, R.color.colorError));
                    tvpartisipanNotVote.setText(partisipanNotVote + " partisipan belum voting");
                }
            }

            @Override
            public void onFinish() {
                containerPartisipanVote.setVisibility(View.INVISIBLE);
                containerTime.setVisibility(View.INVISIBLE);
                checkStateVote();
            }
        }.start();
    }

}
