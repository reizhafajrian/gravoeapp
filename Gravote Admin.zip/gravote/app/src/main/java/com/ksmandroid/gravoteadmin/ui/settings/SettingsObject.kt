package com.ksmandroid.gravoteadmin.ui.settings

import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.model.Setting

object SettingsObject {

    private val name = arrayOf(
        "Edit Profile",
        "Ganti Password",
        "Kontak Kami",
        "Keluar"
    )

    private val settingsGambar = intArrayOf(
        R.drawable.ic_edit_profile,
        R.drawable.ic_change_password,
        R.drawable.ic_contact,
        R.drawable.ic_logout
    )

    val listData: MutableList<Setting>
        get() {
            val list = mutableListOf<Setting>()
            for (position in name.indices) {
                val data = Setting(
                    name[position],
                    settingsGambar[position]
                )
                list.add(data)
            }
            return list
        }

}