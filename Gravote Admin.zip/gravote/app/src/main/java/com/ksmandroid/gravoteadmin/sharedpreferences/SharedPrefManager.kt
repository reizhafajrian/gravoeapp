package com.ksmandroid.gravoteadmin.sharedpreferences

import android.content.Context

class SharedPrefManager(val context: Context) {

    private val PREF_NAME = "com.ksmandroid.gravoteadmin"
    private val LOGIN_VALUE = "com.ksmandroid.gravoteadmin.login"

    private val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun saveStateLogin(state: Boolean) {
        pref.edit().putBoolean(LOGIN_VALUE, state).apply()
    }

    fun isAlreadyLogin(): Boolean {
        return pref.getBoolean(LOGIN_VALUE, false)
    }

    fun clearStateLogin() {
        pref.edit().remove(LOGIN_VALUE).apply()
    }

}