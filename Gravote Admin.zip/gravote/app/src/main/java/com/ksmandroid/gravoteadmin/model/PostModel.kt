package com.ksmandroid.gravoteadmin.model

data class PostModel(
    val titlePost: String,
    val photoPost: String,
    val categoryPost: String,
    val descriptionPost: String,
    val timePost: String,
    val isMemberOnly: Boolean
)
