package com.ksmandroid.gravoteadmin.model

data class Notification(
    val descriptionNotif: String,
    val timeNotif: String,
    val notifRead: String
)

