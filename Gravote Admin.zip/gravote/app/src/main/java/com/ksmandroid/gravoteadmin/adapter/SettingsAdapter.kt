package com.ksmandroid.gravoteadmin.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.listener.SettingsItemClickListener
import com.ksmandroid.gravoteadmin.model.Setting
import kotlinx.android.synthetic.main.item_setting.view.*

class SettingsAdapter(
    private val list: List<Setting>,
    private val listener: SettingsItemClickListener
) :
    RecyclerView.Adapter<SettingsAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view: View =
            LayoutInflater.from(viewGroup.context).inflate(R.layout.item_setting, viewGroup, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(item: Setting) {
            with(itemView) {
                iv_setting.setImageResource(item.icon)
                tv_setting.text = item.name
                setOnClickListener { listener.onItemClick(item.name) }
            }
        }

    }

}
