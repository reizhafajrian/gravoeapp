package com.ksmandroid.gravoteadmin.listener

import com.ksmandroid.gravoteadmin.model.AddPhotoType

interface AddPhotoListener {

    fun onIconClick(addPhotoType: AddPhotoType)

}