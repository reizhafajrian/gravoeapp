package com.ksmandroid.gravoteadmin.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.sharedpreferences.SharedPrefManager;
import com.ksmandroid.gravoteadmin.ui.home.HomeActivity;
import com.ksmandroid.gravoteadmin.ui.register.RegisterActivity;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private TextInputEditText etUsername, etPassword;
    private boolean isClick = true;
    //ketika sudah ada backend variabel dua ini dihapus, karena tidak perlu akun default lagi
    private String defaultUsername = "@ksmandroidupnvj", defaultPassword = "ksmandroidupnvj";
    private String textUsername;
    private String textPassword;
    private SharedPrefManager pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initiatePref();
        initiateUI();

    }

    private void initiatePref() {
        pref = new SharedPrefManager(this);
    }

    private void initiateUI() {
        etUsername = findViewById(R.id.et_username_login);
        etPassword = findViewById(R.id.et_password_login);
        MaterialButton btnLogin = findViewById(R.id.btn_login);
        MaterialButton btnDaftar = findViewById(R.id.btn_daftar);
        ImageButton togglePassword = findViewById(R.id.btn_toggle_password_login);

        btnLogin.setOnClickListener(this);
        btnDaftar.setOnClickListener(this);
        togglePassword.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btn_toggle_password_login:
                if(isClick) {
                    etPassword.setTransformationMethod(
                            HideReturnsTransformationMethod.getInstance());
                    etPassword.setSelection(etPassword.getText().length());
                    isClick = false;
                } else {
                    etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    etPassword.setSelection(etPassword.getText().length());
                    isClick = true;
                }
                break;
            case R.id.btn_login:
                textUsername = etUsername.getText().toString().toLowerCase().trim();
                textPassword = etPassword.getText().toString().toLowerCase().trim();
                if(TextUtils.isEmpty(textUsername) || TextUtils.isEmpty((textPassword))) {
                    Toast.makeText(LoginActivity.this,
                                   getString(R.string.failed_btn_save_login_empty),
                                   Toast.LENGTH_SHORT).show();
                } else if(textUsername.matches(defaultUsername) && textPassword.matches(
                        defaultPassword)) {
                    //setelah backend sudah ada tidak perlu matches dengan default
                    //cukup mendapatkan response dari backend lalu gunakan pref untuk memasukkan data
                    //kemudian intent ke home
                    pref.saveStateLogin(true);
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    //kodingan di bawah digunakan ketika response backend 4xx
                    //atau akun tidak ditemukan
                    Toast.makeText(LoginActivity.this,
                                   getString(R.string.failed_btn_save_login_invalid),
                                   Toast.LENGTH_SHORT).show();
                    etPassword.setText("");
                    if(isClick = true) {
                        etPassword.setTransformationMethod(
                                PasswordTransformationMethod.getInstance());
                        isClick = false;
                    }
                }
                break;
            case R.id.btn_daftar:
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                break;
        }
    }

}