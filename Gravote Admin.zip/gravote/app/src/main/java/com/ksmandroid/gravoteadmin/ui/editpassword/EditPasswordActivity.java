package com.ksmandroid.gravoteadmin.ui.editpassword;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;
import com.ksmandroid.gravoteadmin.R;
import com.ksmandroid.gravoteadmin.listener.BottomSheetItemListener;
import com.ksmandroid.gravoteadmin.utils.CustomTextWatcher;
import com.ksmandroid.gravoteadmin.views.BottomSheetAlertFragment;

public class EditPasswordActivity extends AppCompatActivity
        implements View.OnClickListener, BottomSheetItemListener {

    private TextInputEditText etNowPass, etNewPass, etConfNewPass;
    private MaterialButton btnSave;
    private boolean isClickNowPass = true, isClickNewPass = true, isClickConfNewPass;
    private String textNowPass = "", textNewPass = "", textConfNewPass = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_password);

        iniitiateUI();

    }

    private void iniitiateUI() {
        MaterialTextView tvToolbar = findViewById(R.id.tv_toolbar);
        ImageButton btnBackToolbar = findViewById(R.id.btn_back_toolbar);
        etNowPass = findViewById(R.id.et_now_pass_edit_pass);
        etNewPass = findViewById(R.id.et_new_pass_edit_pass);
        etConfNewPass = findViewById(R.id.et_conf_new_pass_edit_pass);
        ImageButton btnNowPass = findViewById(R.id.btn_toggle_now_pass_edit_pass);
        ImageButton btnNewPass = findViewById(R.id.btn_toggle_new_pass_edit_pass);
        ImageButton btnConfNewPass = findViewById(R.id.btn_toggle_conf_new_pass_edit_pass);
        btnSave = findViewById(R.id.btn_save_edit_pass);

        tvToolbar.setText("Ganti Password");
        etNowPass.addTextChangedListener(editPassTextWatcher);
        etNewPass.addTextChangedListener(editPassTextWatcher);
        etConfNewPass.addTextChangedListener(editPassTextWatcher);
        btnBackToolbar.setOnClickListener(this);
        btnNowPass.setOnClickListener(this);
        btnNewPass.setOnClickListener(this);
        btnConfNewPass.setOnClickListener(this);
        btnSave.setOnClickListener(this);
    }

    private TextWatcher editPassTextWatcher = new CustomTextWatcher() {
        @Override
        public void afterTextChanged(Editable editable) {
            textNowPass = etNowPass.getText().toString().trim();
            textNewPass = etNewPass.getText().toString().trim();
            textConfNewPass = etConfNewPass.getText().toString().trim();
            if(!TextUtils.isEmpty(textNowPass) && !TextUtils.isEmpty(textNewPass) &&
               !TextUtils.isEmpty(textConfNewPass) && textNewPass.matches(textConfNewPass)) {
                btnSave.setEnabled(true);
            } else {
                btnSave.setEnabled(false);
            }
        }
    };

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btn_back_toolbar:
                onBackPressed();
                break;
            case R.id.btn_toggle_now_pass_edit_pass:
                isClickNowPass = btnToggleClicked(isClickNowPass, etNowPass);
                break;
            case R.id.btn_toggle_new_pass_edit_pass:
                isClickNewPass = btnToggleClicked(isClickNewPass, etNewPass);
                break;
            case R.id.btn_toggle_conf_new_pass_edit_pass:
                isClickConfNewPass = btnToggleClicked(isClickConfNewPass, etConfNewPass);
                break;
            case R.id.btn_save_edit_pass:
                validationPassword();
                break;
        }
    }

    private Boolean btnToggleClicked(Boolean state, TextInputEditText et) {
        if(state) {
            et.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            et.setSelection(et.getText().length());
            return false;
        } else {
            et.setTransformationMethod(PasswordTransformationMethod.getInstance());
            et.setSelection(et.getText().length());
            return true;
        }
    }

    public void validationPassword() {
        if(TextUtils.isEmpty(textNowPass) && TextUtils.isEmpty(textNewPass) && TextUtils.isEmpty(
                textConfNewPass)) {
            Toast.makeText(this, "Field tidak boleh ada yang kosong", Toast.LENGTH_LONG).show();
        } else if(!textNewPass.matches(textConfNewPass)) {
            Toast.makeText(this, "Password baru dan konfirmasi password baru harus sama",
                           Toast.LENGTH_SHORT).show();
        } else {
            BottomSheetAlertFragment btsAlert = new BottomSheetAlertFragment(this);
            btsAlert.setTitle("Ganti Password");
            btsAlert.setSubTitle("Apakah kamu yakin ingin mengganti passwordmu?");
            btsAlert.setTextYesBtn("Ya, Saya yakin!");
            btsAlert.show(getSupportFragmentManager(), "Alert");
        }
    }

    @Override
    public void getUserChoice(boolean yes) {
        //Jika user menekan tombol ya
        if(yes) {
            //hit api untuk change password
            Toast.makeText(this, "Password telah diganti", Toast.LENGTH_SHORT).show();
        }
    }

}
