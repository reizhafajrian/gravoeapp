package com.ksmandroid.gravoteadmin.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.listener.SpinnerItemListener
import kotlinx.android.synthetic.main.item_bts_spinner.view.*

class SpinnerBottomSheetAdapter(
    private val listener: SpinnerItemListener,
    private val list: List<String>,
    private val resId: Int
) : RecyclerView.Adapter<SpinnerBottomSheetAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_bts_spinner, parent, false)
        return ViewHolder(view, listener)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(list[position], resId)
    }

    class ViewHolder(itemView: View, private val listener: SpinnerItemListener) :
        RecyclerView.ViewHolder(itemView) {

        fun bind(item: String, resId: Int) {
            with(itemView) {
                tv_spinner.text = item
                setOnClickListener { listener.onItemSpinnerListener(item, resId) }
            }
        }
    }

}