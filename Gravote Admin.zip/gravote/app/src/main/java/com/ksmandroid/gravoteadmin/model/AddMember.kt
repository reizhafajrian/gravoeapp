package com.ksmandroid.gravoteadmin.model

data class AddMember(
    val photo: Int,
    val name: String,
    val username: String,
    var isAdded: Boolean
)