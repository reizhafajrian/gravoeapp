package com.ksmandroid.gravoteadmin.listener

interface SettingsItemClickListener {

    fun onItemClick(nameSetting: String)

}