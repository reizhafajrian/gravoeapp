package com.ksmandroid.gravoteadmin.views

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.adapter.SpinnerBottomSheetAdapter
import com.ksmandroid.gravoteadmin.listener.SpinnerItemListener
import kotlinx.android.synthetic.main.bts_spinner.*

class BottomSheetSpinnerFragment(
    context: Context,
    private val listener: SpinnerItemListener
) : BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.bts_spinner, container)
    }

    private val contextSpinner = context
    private var title = ""
    private var resId = 0
    private var listSpinner = listOf<String>()

    fun setTitle(text: String) {
        title = text
    }

    fun setResId(id: Int) {
        resId = id
    }

    fun setList(list: List<String>) {
        listSpinner = list
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tv_title_bts_spinner.text = title
        val linearLayoutManager = LinearLayoutManager(contextSpinner)
        val adapter =
            SpinnerBottomSheetAdapter(
                listener,
                listSpinner,
                resId
            )
        rv_bts_spinner.layoutManager = linearLayoutManager
        rv_bts_spinner.adapter = adapter
    }

}