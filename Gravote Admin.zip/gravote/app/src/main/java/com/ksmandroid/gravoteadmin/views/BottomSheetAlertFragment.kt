package com.ksmandroid.gravoteadmin.views

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.listener.BottomSheetItemListener
import kotlinx.android.synthetic.main.bts_alert.*

class BottomSheetAlertFragment(private val listener: BottomSheetItemListener) :
    BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.bts_alert, container)
    }

    private var title: String? = ""
    private var subTitle: String? = ""
    private var textYesBtn: String? = ""
    private var textNoBtn: String? = ""

    fun setTitle(text: String?) {
        title = text
    }

    fun setSubTitle(text: String?) {
        subTitle = text
    }

    fun setTextYesBtn(text: String?) {
        textYesBtn = text
    }

    fun setTextNoBtn(text: String?) {
        textNoBtn = text
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tv_title_bts_dialog.text = title
        tv_sub_title_bts.text = subTitle
        btn_yes_bts.text = textYesBtn
        btn_no_bts.text = textNoBtn
        btn_no_bts.setOnClickListener {
            this.dismiss()
        }
        btn_yes_bts.setOnClickListener {
            listener.getUserChoice(true)
        }
    }
}