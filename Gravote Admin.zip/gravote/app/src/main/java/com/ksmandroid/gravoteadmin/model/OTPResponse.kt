package com.ksmandroid.gravoteadmin.model

data class OTPResponse(val status: String?)