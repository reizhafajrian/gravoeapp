package com.ksmandroid.gravoteadmin.ui.register

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.adapter.ListPhotoAdapter
import com.ksmandroid.gravoteadmin.listener.AddPhotoListener
import com.ksmandroid.gravoteadmin.listener.SpinnerItemListener
import com.ksmandroid.gravoteadmin.model.AddPhotoType
import com.ksmandroid.gravoteadmin.utils.ExtraKey.Companion.FROM_CAMERA_CODE
import com.ksmandroid.gravoteadmin.utils.ExtraKey.Companion.FROM_GALLERY_CODE
import com.ksmandroid.gravoteadmin.utils.ExtraKey.Companion.PERMISSION_CODE
import com.ksmandroid.gravoteadmin.views.BottomSheetAddPhotoFragment
import com.ksmandroid.gravoteadmin.views.BottomSheetSpinnerFragment
import kotlinx.android.synthetic.main.activity_register_profile.*
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.longToast

class RegisterProfileActivity : AppCompatActivity(), View.OnClickListener,
    SpinnerItemListener,
    AddPhotoListener {

    private var imageCameraUri: Uri? = Uri.EMPTY
    private var resIdPhoto: Int? = 0
    private var isFromCamera: Boolean? = true
    private var imageUri: Uri? = Uri.EMPTY
    private var textNameOrganization = ""
    private var textScopeOrganization = ""
    private var textTypeOrganization = ""
    private var textUniversity = ""
    private var textFaculty = ""
    private val listPhoto = mutableListOf<Uri?>()
    private val listLingkupOrganisasi = listOf("Internal", "Eksternal")
    private val listJenisOrganisasi =
        listOf("Kelompok Studi Mahasiswa", "Badan Eksekutif Mahasiswa")
    private val listUniversitas = listOf("UPN Veteran Jakarta")
    private val listFakultas = listOf(
        "Fakultas Ekonomi dan Bisnis",
        "Fakultas Teknik",
        "Fakultas Ilmu Komputer",
        "Fakultas Hukum",
        "Fakultas Ilmu Sosial dan Ilmu Politik",
        "Fakultas Kedokteran",
        "Fakultas Ilmu Kesehatan"
    )

    private val btsAddPhoto by lazy { BottomSheetAddPhotoFragment(this) }
    private val btsSpinner by lazy { BottomSheetSpinnerFragment(this, this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_profile)

        initiateUI()

    }

    private fun initiateUI() {
        btn_add_photo_regis_profile.setOnClickListener(this)
        tv_add_photo_regis_profile.setOnClickListener(this)
        et_scope_organization_regis_profile.setOnClickListener(this)
        et_type_organization_regis_profile.setOnClickListener(this)
        et_university_regis_profile.setOnClickListener(this)
        et_faculty_regis_profile.setOnClickListener(this)
        btn_add_photo_header_regis_profile.setOnClickListener(this)
        btn_save_regis_profile.setOnClickListener(this)
        showListPhoto()
    }

    private fun showListPhoto() {
        rv_photo_organization_regis_profile.setHasFixedSize(true)
        rv_photo_organization_regis_profile.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        val listPhotoAdapter = ListPhotoAdapter(listPhoto)
        rv_photo_organization_regis_profile.adapter = listPhotoAdapter
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_save_regis_profile -> {
                textNameOrganization = et_name_organization_regis_profile.text.toString().trim()
                if (imageUri != Uri.EMPTY && textNameOrganization.isNotEmpty() &&
                    textScopeOrganization.isNotEmpty() && textTypeOrganization.isNotEmpty() &&
                    textUniversity.isNotEmpty() && textFaculty.isNotEmpty() && listPhoto.isNotEmpty()
                ) {
                    // hit api untuk kirim ke backend
                    startActivity(intentFor<RegisterAddMemberWelcomeActivity>())
                } else {
                    longToast(getString(R.string.failed_btn_save_field_empty))
                }
            }
            R.id.btn_add_photo_regis_profile, R.id.tv_add_photo_regis_profile -> {
                showAddPhotoBottomSheet(R.id.btn_add_photo_regis_profile)
            }
            R.id.btn_add_photo_header_regis_profile -> {
                showAddPhotoBottomSheet(R.id.btn_add_photo_header_regis_profile)
            }
            R.id.et_scope_organization_regis_profile -> {
                showSpinnerBottomSheet(
                    getString(R.string.title_spinner_bottom_sheet_scope_organization),
                    R.id.et_scope_organization_regis_profile,
                    listLingkupOrganisasi
                )
            }
            R.id.et_type_organization_regis_profile -> {
                showSpinnerBottomSheet(
                    getString(R.string.title_spinner_bottom_sheet_type_organization),
                    R.id.et_type_organization_regis_profile,
                    listJenisOrganisasi
                )
            }
            R.id.et_university_regis_profile -> {
                showSpinnerBottomSheet(
                    getString(R.string.title_spinner_bottom_sheet_university_name),
                    R.id.et_university_regis_profile,
                    listUniversitas
                )
            }
            R.id.et_faculty_regis_profile -> {
                showSpinnerBottomSheet(
                    getString(R.string.title_spinner_bottom_sheet_faculty_name),
                    R.id.et_faculty_regis_profile,
                    listFakultas
                )
            }
        }
    }

    private fun showAddPhotoBottomSheet(resId: Int) {
        resIdPhoto = resId
        btsAddPhoto.show(supportFragmentManager, getString(R.string.tag_bottom_sheet_add_photo))
    }

    private fun showSpinnerBottomSheet(title: String, resId: Int, list: List<String>) {
        btsSpinner.setTitle(title)
        btsSpinner.setResId(resId)
        btsSpinner.setList(list)
        btsSpinner.show(supportFragmentManager, getString(R.string.tag_bottom_sheet_spinner))
    }

    private fun pickImageFromCamera() {
        //if system os is Marshmallow or Above, we need to request runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED ||
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED
            ) {
                //permission was not enabled
                val permission =
                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                isFromCamera = true
                //show popup to request permission
                requestPermissions(
                    permission,
                    PERMISSION_CODE
                )
            } else {
                //permission already granted
                openCamera()
            }
        } else {
            //system os is < marshmallow
            openCamera()
        }
    }

    private fun pickImageFromGallery() {
        //if system os is Marshmallow or Above, we need to request runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED ||
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED
            ) {
                //permission was not enabled
                val permission =
                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                isFromCamera = false
                //show popup to request permission
                requestPermissions(
                    permission,
                    PERMISSION_CODE
                )
            } else {
                //permission already granted
                openGallery()
            }
        } else {
            //system os is < marshmallow
            openGallery()
        }
    }

    private fun openGallery() {
        //Intent to pick image
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, FROM_GALLERY_CODE)
    }

    private fun openCamera() {
        val values = ContentValues()
        values.put(MediaStore.Images.Media.TITLE, "New Picture")
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera")
        imageCameraUri =
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        //camera intent
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageCameraUri)
        startActivityForResult(intent, FROM_CAMERA_CODE)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        //called when user presses ALLOW or DENY from Permission Request Popup
        when (requestCode) {
            PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    when (isFromCamera) {
                        true -> pickImageFromCamera()
                        false -> pickImageFromGallery()
                    }
                } else {
                    //permission from popup was denied
                    Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT)
                        .show()
                    btsAddPhoto.dismiss()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && resIdPhoto == R.id.btn_add_photo_regis_profile) {
            when (requestCode) {
                FROM_CAMERA_CODE -> {
                    btn_add_photo_regis_profile.setImageURI(imageCameraUri)
                    imageUri = imageCameraUri
                }

                FROM_GALLERY_CODE -> {
                    btn_add_photo_regis_profile.setImageURI(data?.data)
                    imageUri = data?.data

                }
            }
        } else if (resultCode == Activity.RESULT_OK && resIdPhoto == R.id.btn_add_photo_header_regis_profile) {
            when (requestCode) {
                FROM_CAMERA_CODE -> {
                    listPhoto.add(imageCameraUri)
                }

                FROM_GALLERY_CODE -> {
                    listPhoto.add(data?.data)
                }
            }
            showListPhoto()
        } else {
            longToast(getString(R.string.failed_add_photo))
        }
        btsAddPhoto.dismiss()
    }

    override fun onItemSpinnerListener(text: String, resId: Int) {
        when (resId) {
            R.id.et_name_organization_regis_profile -> {
                et_name_organization_regis_profile.setText(text)
                textNameOrganization = text
            }
            R.id.et_scope_organization_regis_profile -> {
                et_scope_organization_regis_profile.setText(text)
                textScopeOrganization = text
            }
            R.id.et_type_organization_regis_profile -> {
                et_type_organization_regis_profile.setText(text)
                textTypeOrganization = text
            }
            R.id.et_university_regis_profile -> {
                et_university_regis_profile.setText(text)
                textUniversity = text
            }
            R.id.et_faculty_regis_profile -> {
                et_faculty_regis_profile.setText(text)
                textFaculty = text
            }
        }
        btsSpinner.dismiss()
    }

    override fun onIconClick(addPhotoType: AddPhotoType) {
        when (addPhotoType) {
            AddPhotoType.CAMERA -> pickImageFromCamera()
            AddPhotoType.GALLERY -> pickImageFromGallery()
        }
    }

}