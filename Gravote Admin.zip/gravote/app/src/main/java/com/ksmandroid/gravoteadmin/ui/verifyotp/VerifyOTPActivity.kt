package com.ksmandroid.gravoteadmin.ui.verifyotp

import android.os.Bundle
import android.os.CountDownTimer
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.textfield.TextInputEditText
import com.ksmandroid.gravoteadmin.R
import com.ksmandroid.gravoteadmin.model.OTPResponse
import com.ksmandroid.gravoteadmin.network.OTPNetworkConfig
import com.ksmandroid.gravoteadmin.utils.CustomTextWatcher
import com.ksmandroid.gravoteadmin.utils.changeToIndoCodeNumbers
import com.ksmandroid.gravoteadmin.utils.splitPhoneNumbers
import com.ksmandroid.gravoteadmin.views.LoadingDialog
import kotlinx.android.synthetic.main.activity_verify_otp.*
import org.jetbrains.anko.longToast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VerifyOTPActivity : AppCompatActivity() {

    private var time: Long = 240000
    private var stop = false
    private val ctx by lazy { this }
    private lateinit var code: String

    private val loadingDialog by lazy { LoadingDialog(this) }
    private val splitPhoneNumbers by lazy {
        intent.getStringExtra("phoneNumbers")?.splitPhoneNumbers()
    }
    private val indoCodePhoneNumbers by lazy {
        intent.getStringExtra("phoneNumbers")?.changeToIndoCodeNumbers()
    }
    private val api by lazy { OTPNetworkConfig(this).api() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify_otp)

        initiateUI()
        timeOtp()
    }

    private fun initiateUI() {
        val tvPhoneNumbers = getString(R.string.title_verify_otp) + " " + splitPhoneNumbers
        tv_title_verify_otp.text = tvPhoneNumbers
        setUpEtOtp(et_verify_otp_1, et_verify_otp_2)
        setUpEtOtp(et_verify_otp_2, et_verify_otp_3)
        setUpEtOtp(et_verify_otp_3, et_verify_otp_4)
        setUpEtOtp(et_verify_otp_4, et_verify_otp_5)
        setUpEtOtp(et_verify_otp_5, et_verify_otp_6)
        setUpEtOtp(et_verify_otp_6, et_verify_otp_6)
    }

    private fun setUpEtOtp(etFirst: TextInputEditText, etNext: TextInputEditText) {
        etFirst.addTextChangedListener(object : CustomTextWatcher() {
            override fun onTextChanged(text: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (etFirst != et_verify_otp_6) {
                    etNext.requestFocus()
                } else {
                    verifyOtp()
                }
            }
        })
    }

    private fun verifyOtp() {
        loadingDialog.showDialog()
        api.verifyOTP(indoCodePhoneNumbers, code)
            .enqueue(object : Callback<OTPResponse> {
                override fun onFailure(call: Call<OTPResponse>, t: Throwable) {
                    loadingDialog.hideDialog()
                    longToast(getString(R.string.failed_connection))
                }

                override fun onResponse(
                    call: Call<OTPResponse>,
                    response: Response<OTPResponse>
                ) {
                    loadingDialog.hideDialog()
                    if (response.body()?.status == "approved") {
                        longToast(getString(R.string.success_verify_otp))
                        stop = true
                        // Move Activity here
                        //val move = Intent(this@VerifyOTPActivity, Berhasil::class.java)
                        //startActivity(move)
                    } else {
                        longToast(getString(R.string.failed_verify_otp))
                    }
                }
            })
    }

    private fun timeOtp() {
        object : CountDownTimer(time, 1000) {
            override fun onTick(time: Long) {
                if (stop) cancel()
                else {
                    val minute: String = ((time / 1000) / 60).toString()
                    var second: String = ((time / 1000) % 60).toString()
                    if (second.toInt() < 10) second = "0$second"
                    val textTime = ("Kirim ulang kode dalam 0$minute:$second menit")
                    val colorTime = SpannableString(textTime)
                    val blue = ForegroundColorSpan(ContextCompat.getColor(ctx, R.color.colorAccent))
                    colorTime.setSpan(blue, 22, 28, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    tv_time_otp.text = (colorTime)
                }
            }

            override fun onFinish() {
                requestOtp()
            }
        }.start()
    }

    private fun requestOtp() {
        loadingDialog.showDialog()
        api.requestOtp(indoCodePhoneNumbers, getString(R.string.request_channel_otp))
            .enqueue(object : Callback<OTPResponse> {
                override fun onFailure(call: Call<OTPResponse>, t: Throwable) {
                    loadingDialog.hideDialog()
                    longToast(getString(R.string.failed_connection))
                }

                override fun onResponse(
                    call: Call<OTPResponse>, response: Response<OTPResponse>
                ) {
                    loadingDialog.hideDialog()
                    if (response.body()?.status.toString() == "pending") {
                        longToast(getString(R.string.success_request_again_otp))
                        timeOtp()
                    } else {
                        longToast(getString(R.string.failed_verify_otp_phone_numbers_invalid))
                        timeOtp()
                    }
                }
            })
    }
}
